﻿Imports MySql.Data.MySqlClient

'Melanie Galaretto
Public Class Form1
    Private Sub btnRegistrar_Click(sender As Object, e As EventArgs) Handles btnRegistrar.Click

        Dim conexion As MySqlConnection
        conexion = New MySqlConnection
        Dim cmd As New MySqlCommand

        conexion.ConnectionString = "server=localhost;database=encuesta;Uid=root;Pwd=;"

        If txtNombre.Text = "" Or txtApellido.Text = "" Or cbxSerie.Text = "" Then

            MsgBox("Error, debe ingresar todo los datos")

        Else
            Try
                conexion.Open()
                MsgBox("Conectado con la base de datos")
                cmd.Connection = conexion

                cmd.CommandText = "INSERT INTO encuesta_series(nombre, apellido, serie_favorita) VALUES (@nombre, @apellido, @serie_favorita)"
                cmd.Prepare()

                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text)
                cmd.Parameters.AddWithValue("@apellido", txtApellido.Text)
                cmd.Parameters.AddWithValue("@serie_favorita", cbxSerie.Text)
                cmd.ExecuteNonQuery()

                conexion.Close()
                txtNombre.Clear()
                txtApellido.Clear()
                cbxSerie.Text = ""
                MsgBox("Datos correctamente ingresados")

            Catch ex As Exception
                MsgBox("No conectado con la base de datos")
            End Try

        End If

    End Sub
End Class
